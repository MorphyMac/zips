package com.example.email.service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.Locale;
import java.util.Map;

@Component
public class TemplateProcessor {
    @Autowired
    private TemplateEngine emailTemplateEngine;

    public String processHtml(String template, Map<String, Object> context, Locale locale) {
        return this.emailTemplateEngine.process(template, new Context(locale, context));
    }
}