/*
 * =============================================================================
 *
 *   Copyright (c) 2011-2014, The THYMELEAF team (http://www.thymeleaf.org)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.example.email.service.controller;

import com.example.email.service.model.DataSourceItem;
import com.example.email.service.model.Mail;
import com.example.email.service.service.EmailService;
import com.example.email.service.service.TemplateProcessor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.validation.Valid;
import java.io.IOException;
import java.util.*;

@Slf4j
@RestController
public class SendingController {

    private static final String SENT = "Sent !!";
    private static final String FROM = "bhallasaabemailtesting@gmail.com";
    private static final String TO = FROM;
    private static final String INLINE_IMAGES_LOCATION = "/mail/inline-images/";
    private static final String ATTACHMENTS_LOCATION = "/mail/attachments/";
    @Autowired
    private EmailService emailService;
    @Autowired
    private TemplateProcessor templateProcessor;

    @PostMapping("/sendMailWithAttachment")
    public ResponseEntity<String> sendMail(@RequestParam(value = "attachments", required = false) final MultipartFile[] attachments
            /*,@RequestParam(value = "inlineItems", required = false) final MultipartFile[] inlineItems*/)
            throws MessagingException, IOException {

        //
        //
        // NOTE: inline items needs to be added in Mail object and ContextVariable both
        //
        //
        // contextVariables.put(........, "logo_id"); // cid:header_image_id
        // mail.addInline("logo_id", ........ ))

        // thymeleaf context
        Map<String, Object> contextVariables = new HashMap<>();
        contextVariables.put("name", "John Doe");
        contextVariables.put("subscriptionDate", new Date());
        contextVariables.put("hobbies", Arrays.asList("Cinema", "Sports", "Music"));
        contextVariables.put("inlineImage_1_HolderName", "header_image_id"); // cid:header_image_id
        contextVariables.put("inlineImage_2_HolderName", "logo_id"); // cid:header_image_id
        String body = templateProcessor.processHtml("email-inlineimage", contextVariables, Locale.US);


        // mail
        Mail mail = Mail.builder().from(FROM).to(TO).subject("Sample email subject").build();
        mail.setBody(body);
        mail.setHtml(true);
        mail.setSanitizeInlineImages(true);

        addMultipartAttachments(mail, attachments);
        classpathAttachments().forEach(mail::addAttachment);

        classpathInlineItems().forEach(mail::addInlineItem);

        this.emailService.sendMail(mail);

        return ResponseEntity.ok(SENT);
    }

    @PostMapping("/notification/email")
    public ResponseEntity<String> sendMail(@Valid @RequestBody Mail mail) throws MessagingException {
        this.emailService.sendMail(mail);
        return ResponseEntity.ok(SENT);
    }

    private List<DataSourceItem> classpathAttachments() throws IOException {
        return Collections.singletonList(
                //
                classpathResource("passport_size_pic_new_anwaralam.jpeg", ATTACHMENTS_LOCATION,
                        "passport_size_pic_new_anwaralam.jpeg", MimeTypeUtils.IMAGE_JPEG_VALUE));
    }

    private List<DataSourceItem> classpathInlineItems() throws IOException {
        return Arrays.asList(
                //
                classpathResource("header_image_id", INLINE_IMAGES_LOCATION, "assist-header.jpg",
                        MimeTypeUtils.IMAGE_JPEG_VALUE),
                //
                classpathResource("logo_id", INLINE_IMAGES_LOCATION, "epam-logo.png", MimeTypeUtils.IMAGE_PNG_VALUE));
    }

    private DataSourceItem classpathResource(String contentId, String folder, String filename, String mimeType)
            throws IOException {
        byte[] resource = IOUtils.toByteArray(new ClassPathResource(folder + filename).getInputStream());
        return DataSourceItem.builder().contentId(contentId).contentType(mimeType).content(resource).build();
    }

    public void addInlineItems(Mail mail, MultipartFile[] inlineItems) {
        if (Objects.isNull(inlineItems)) {
            log.debug("Inline items not found while adding to mail");
            return;
        }

        Arrays.stream(inlineItems).forEach(inlineItem -> {
            try {
                DataSourceItem inlineItemDs = DataSourceItem.builder().contentId(inlineItem.getOriginalFilename())
                                                            .contentType(inlineItem.getContentType())
                                                            .content(inlineItem.getBytes()).build();
                mail.addInlineItem(inlineItemDs);
            } catch (IOException e) {
                log.error("Error adding attachment. filename: {}", inlineItem.getOriginalFilename());
            }
        });
    }

    private void addMultipartAttachments(Mail mail, MultipartFile[] attachments) {
        if (Objects.isNull(attachments)) {
            log.debug("Attachments not found while adding to mail");
            return;
        }

        Arrays.stream(attachments).forEach(attachment -> {
            try {
                DataSourceItem attachmentItem = DataSourceItem.builder().contentId(attachment.getOriginalFilename())
                                                              .contentType(attachment.getContentType())
                                                              .content(attachment.getBytes()).build();
                mail.addAttachment(attachmentItem);
            } catch (IOException e) {
                log.error("Error adding attachment. filename: {}", attachment.getOriginalFilename());
            }
        });
    }
}