package com.example.email.service.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataSourceItem implements Serializable {
    private String contentId; // filename (attachment) or contentId (inline)
    private String contentType;
    private byte[] content;
}