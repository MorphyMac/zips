package com.example.email.service.exceptions;

public class InlineImageAdditionFailed extends RuntimeException {
    public InlineImageAdditionFailed() {
        super("Failed adding inline image to HTML email body.");
    }

    public InlineImageAdditionFailed(String message) {
        super(message);
    }

    public InlineImageAdditionFailed(String message, Throwable cause) {
        super(message, cause);
    }

    public InlineImageAdditionFailed(Throwable cause) {
        super(cause);
    }

    public InlineImageAdditionFailed(String message, Throwable cause, boolean enableSuppression,
                                     boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}