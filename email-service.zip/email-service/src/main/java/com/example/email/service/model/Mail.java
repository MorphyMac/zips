package com.example.email.service.model;

import lombok.*;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Mail implements Serializable {

    @NonNull
    private String from;
    @NonNull
    private String to;
    private String subject;
    private String body;
    private boolean html;
    @Builder.Default
    private List<DataSourceItem> attachments = Collections.emptyList();
    @Builder.Default
    private List<DataSourceItem> inlineItems = Collections.emptyList();
    @Builder.Default
    private boolean sanitizeInlineImages = false;

    public Mail(String from, String to, String subject) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.body = "";
    }

    public Mail addAttachment(DataSourceItem attachment) {
        if (CollectionUtils.isEmpty(this.attachments)) {
            this.attachments = new ArrayList<>();
        }

        this.attachments.add(attachment);
        return this;
    }

    public Mail addInlineItem(DataSourceItem inlineItem) {
        if (CollectionUtils.isEmpty(this.inlineItems)) {
            this.inlineItems = new ArrayList<>();
        }

        this.inlineItems.add(inlineItem);
        return this;
    }
}