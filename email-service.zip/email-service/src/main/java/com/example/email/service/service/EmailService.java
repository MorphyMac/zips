/*
 * =============================================================================
 *
 *   Copyright (c) 2011-2014, The THYMELEAF team (http://www.thymeleaf.org)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.example.email.service.service;

import com.example.email.service.exceptions.AttachmentAdditionFailed;
import com.example.email.service.exceptions.InlineImageAdditionFailed;
import com.example.email.service.model.DataSourceItem;
import com.example.email.service.model.Mail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendMail(Mail mail) throws MessagingException {
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true /* multipart */, "UTF-8");

        message.setTo(mail.getTo());
        message.setFrom(mail.getFrom());
        message.setSubject(mail.getSubject());
        message.setText(StringUtils.hasLength(mail.getBody()) ? mail.getBody() : "", mail.isHtml());

        addAttachments(message, mail);
        addInlineImages(message, mail);

        if (mail.isHtml() && !CollectionUtils.isEmpty(mail.getInlineItems())) {
            logInlineImageSanity(mail);
        }

        this.mailSender.send(mimeMessage);
    }

    private void addInlineImages(MimeMessageHelper message, Mail mail) {
        // add inline image
        mail.getInlineItems().forEach(dataSourceItem -> {
            // Add the inline image, referenced from the HTML code as "cid:${dataSourceItem.getContentId()}"
            // mail.getBody() contains "cid:${dataSourceItem.getContentId()}" eg. "cid:${logo}"
            try {
                final InputStreamSource imageSource = new ByteArrayResource(dataSourceItem.getContent());
                message.addInline(dataSourceItem.getContentId(), imageSource, dataSourceItem.getContentType());
            } catch (MessagingException e) {
                log.error("Failed adding inline content. content: {}", dataSourceItem.getContentId());
                throw new AttachmentAdditionFailed("Failed adding inline content. content: " + dataSourceItem
                        .getContentId());
            }
        });
    }

    private void addAttachments(MimeMessageHelper message, Mail mail) {
        // Add the attachment
        mail.getAttachments().forEach(dataSourceItem -> {
            try {
                final InputStreamSource attachmentSource = new ByteArrayResource(dataSourceItem.getContent());
                message.addAttachment(dataSourceItem.getContentId(), attachmentSource, dataSourceItem.getContentType());
            } catch (MessagingException e) {
                log.error("Failed adding attachment. filename: {}", dataSourceItem.getContentId());
                throw new InlineImageAdditionFailed("Failed adding attachment. filename: " + dataSourceItem
                        .getContentId());
            }
        });
    }

    private void logInlineImageSanity(Mail mail) {
        try {
            if (mail.isSanitizeInlineImages() && mail.isHtml() && !CollectionUtils.isEmpty(mail.getInlineItems())) {
                log.debug("\n\n##################  mail inlineImages sanity : START");

                final String cid = "cid:";
                String body = mail.getBody();

                List<Integer> indexes = cidOccurrence(body);

                log.debug("HTML email body:\n{}", body);
                log.debug("Content-Id (cid) occurrence in inlineItems: {}", mail.getInlineItems().size());
                log.debug("Content-Id (cid) occurrence in mail HTML body. count: {}", indexes.size());
                log.debug("Content-Id (cid) occurrence in mail HTML body. indexes: {}", indexes);

                List<String> contentIds = getContentIds(body);
                log.debug("Content-Ids (cid) in mail body. CIDs = {}", contentIds);

                List<String> matching = contentIds.parallelStream().filter(id -> mail.getInlineItems().parallelStream()
                                                                                     .map(DataSourceItem::getContentId)
                                                                                     .anyMatch(item -> item.equals(id
                                                                                             .replaceFirst(cid, ""))))
                                                  .collect(Collectors.toList());
                log.debug("Content-Ids (cid) - match found. CIDs = {}", matching);

                List<String> noneMatching = contentIds.parallelStream()
                                                      .filter(id -> mail.getInlineItems().parallelStream()
                                                                        .map(DataSourceItem::getContentId)
                                                                        .noneMatch(item -> item
                                                                                .equals(id.replaceFirst(cid, ""))))
                                                      .collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(noneMatching)) {
                    log.warn("Content-Ids (cid) - match NOT found. CIDs = {}", noneMatching);
                    mail.getInlineItems().forEach(dataSourceItem -> {
                        String imageId = "cid:${" + dataSourceItem.getContentId() + "}";
                        if (!body.contains(imageId)) {
                            log.warn("NOT FOUND - content-id (cid) for inlineImage in HTML body. content-id: {}",
                                    imageId);
                        }
                    });
                }

                log.debug("##################  mail inlineImages sanity : END\n\n");
            }
        } catch (Exception e) {
            log.error("Error logging inlineImages sanity. error: {}", e.getMessage());
        }
    }

    private List<Integer> cidOccurrence(String s) {
        List<Integer> indexList = new ArrayList<>();
        final String cid = "cid:";

        int initialIndex = s.indexOf(cid);
        while (initialIndex >= 0) {
            indexList.add(initialIndex);
            initialIndex = s.indexOf(cid, initialIndex + 1);
        }

        return indexList.stream().mapToInt(i -> i).boxed().collect(Collectors.toList());
    }

    private List<String> getContentIds(final String body) {
        List<String> indexList = new ArrayList<>();

        try {
            final String subString = "cid:";
            String temp = body;

            int initialIndex = temp.indexOf(subString);
            while (initialIndex >= 0) {
                String nextStart = temp.substring(initialIndex);
                indexList.add(temp.substring(initialIndex, initialIndex + nextStart.indexOf(" ") - 1));
                temp = nextStart;
                initialIndex = temp.indexOf(subString, temp.indexOf(subString) + 1);
            }
        } catch (Exception e) {
            log.error("Failed to get content-ids from HTML body. body: {}, \n error: {}", body, e.getMessage());
        }

        return indexList;
    }
}