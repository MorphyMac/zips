package com.example.email.service.exceptions;

public class AttachmentAdditionFailed extends RuntimeException {
    public AttachmentAdditionFailed() {
        super("Failed adding attachment to email.");
    }

    public AttachmentAdditionFailed(String message) {
        super(message);
    }

    public AttachmentAdditionFailed(String message, Throwable cause) {
        super(message, cause);
    }

    public AttachmentAdditionFailed(Throwable cause) {
        super(cause);
    }

    public AttachmentAdditionFailed(String message, Throwable cause, boolean enableSuppression,
                                    boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}